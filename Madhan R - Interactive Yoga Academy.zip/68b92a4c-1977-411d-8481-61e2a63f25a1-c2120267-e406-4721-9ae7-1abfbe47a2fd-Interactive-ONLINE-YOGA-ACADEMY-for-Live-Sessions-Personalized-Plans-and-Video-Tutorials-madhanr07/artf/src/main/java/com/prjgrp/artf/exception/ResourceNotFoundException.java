package com.prjgrp.artf.exception;

public class ResourceNotFoundException {
    
}
    